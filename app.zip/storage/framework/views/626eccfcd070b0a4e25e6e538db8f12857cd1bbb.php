<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-12"> 
            <div class="card">
                <div class="card-header" align="center">
                    <div class="card-header" style="background-color: rgb(78, 190, 249); color: rgb(0, 0, 0)" >
                        <b>DAFTAR PEMBELI</b> 
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<br>

<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12"> 
            <div class="card">
                <form action="/filters" method="GET">
                    <div class="card-header">
                        <div class="panel panel-default">
                            <div class="panel-heading">
                                <div class="row justify-content-center">
                                    <!-- style="text-align:justify" -->
                                        
                                        Dari

                                        <div class="col-md-2">
                                            <input type="date" name="start" class="form-control" value="<?php echo date('Y-m-d');?>">
                                        </div>
                                        Ke
                                        <div class="col-md-2">
                                            <input type="date" name="end" class="form-control" value="<?php echo date('Y-m-d');?>">
                                        </div>
                                        <div class="col-md-2">
                                            <input type="submit" value="Filter">
                                        </div>
                                    
                                    </form>

                                    

                                    <div class="col-md-4">
                                        <form action="/caris" method="GET" align="right">
                                            <input type="text" name="cari" placeholder="Cari nama pembeli..." value="<?php echo e(old('cari')); ?>">
                                            <input type="submit" value="Cari"> 
                                            <a href="<?php echo e(route('laporans.index')); ?>" class="btn btn-warning btn-sm">Refresh</a>

                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                <!-- </form> -->




                <div class="card-body">
                    <?php if(session()->get('success')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session()->get('success')); ?>

                        </div>
                    <?php endif; ?> 

                    <form>
                        <div class=" col-md-2">
                            <a href="<?php echo e(url('export')); ?>" class="btn btn-success btn-sm">Download</a>
                        </div><br>
                        <div id="order_table">
                        <table class="table table-bordered">
                            <thead>
                                <tr>

                                    <th width="2%" >#</th>
                                    <th width="10%">Tanggal</th>
                                    <th width="22%">Nama Pembeli</th>
                                    <th width="22%">Nama Barang</th>
                                    <th width="12%">Harga Barang</th>
                                    <th width="1%">Jumlah</th>
                                    <th width="12%">Total BON</th>
                                    
                                    <!-- <th>Kontrol</th> -->
                                </tr>
                            </thead>
                            <?php $no = 1; ?>
                            <?php $__currentLoopData = $laporans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pembeli): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tbody>
                                    <tr>
                                        <td><?php echo e($no++); ?></td>
                                        <td><?php echo e($pembeli->created_at->format('Y-m-d')); ?></td> 
                                        <td><?php echo e($pembeli->nama_pembeli); ?></td>
                                        <td><?php echo e($pembeli->nama_produk); ?></td>
                                        <td><?php echo e("Rp. ".number_format($pembeli->harga, 0, ".", "." )); ?></td>
                                        <td><?php echo e($pembeli->jumlah); ?></td>
                                        <td><?php echo e("Rp. ".number_format($pembeli->total, 0, ".", "." )); ?></td>  
                                    </tr>
                                
                                </tbody>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </table>
                        </div> 
                    </form>
                    <hr>
                    Halaman : <?php echo e($laporans->currentPage()); ?> <br/>
                    Jumlah Pembeli : <?php echo e($laporans->total()); ?> <br/>
                    Data Per Halaman : <?php echo e($laporans->perPage()); ?> <br/>
                    
                    <?php echo $laporans->appends(Request::except('page'))->links(); ?>

                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>