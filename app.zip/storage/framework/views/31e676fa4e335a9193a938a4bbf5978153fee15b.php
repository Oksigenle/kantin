<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-4">
            <div class="card">
                <div class="card-header" align="center">
                    <div class="card-header" align="center" style="background-color: rgb(78, 190, 249); color: rgb(0, 0, 0)" >
                        <b>Add Produk</b>
                    </div>
                </div>

                <div class="card-body">
                    <div class="card-body">
                        <?php if($errors->any()): ?>
                        <div class="alert alert-danger">
                            <ul>
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($error); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div><br />
                        <?php endif; ?>
                        <form method="post" action="<?php echo e(route('produks.store')); ?>">
                            <div class="form-group">
                                <?php echo csrf_field(); ?>
                                <label for="name">Nama produk:</label>
                                <input type="text" class="form-control" name="nama_produk"/>
                            </div>
                            <div class="form-group">
                                <label for="price">Harga :</label>
                                <input type="text" class="form-control" name="harga"/>
                            </div>
                            <div class="form-group">
                                <label for="quantity">Stok:</label>
                                <input type="text" class="form-control" name="stok"/>
                            </div>

                            <div class="form-group">
                                <label for="quantity">Kode Produk:</label>
                                <input type="text" class="form-control" name="kode_produk"/>
                            </div>
                            <button type="submit" class="btn btn-success">Add</button>
                            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                            &nbsp;&nbsp;&nbsp;&nbsp;
                            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                            <a href="<?php echo e(url('/produks')); ?>" class="btn btn-primary">Back</a>
                            <!-- <a href="javascript:history.back()" class="btn btn-primary">Back</a> -->
                        </form>
                    </div>
                    
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>