<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header" align="center">
                    <div class="card-header" style="background-color: rgb(78, 190, 249); color: rgb(0, 0, 0)" >
                        <b>DAFTAR BARANG</b>
                    </div>
                </div> 

                <div class="card-header">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            <div class="row justify-content-center">
                                <div class="col-md-2">
                                    <a href="<?php echo e(route('produks.create')); ?>" class="btn btn-primary">Tambah</a>
                                </div>
                                <div class="col-sm-10">

                                    <form action="<?php echo e(route('cari')); ?>" method="GET" align="right">
                                    <input type="text" name="cari" placeholder="Cari nama produk..." value="<?php echo e(old('cari')); ?>">
                                    <input type="submit" value="Cari">
                                </form>
                            </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>

                    
                    <br>
 
                    <table class="table">
                        <thead>
                            <tr>
                                <th>No</th>
                                <th>Kode Produk</th>
                                <th>Nama Produk</th> 
                                <th>Harga</th>
                                <th>Stok</th>
                                <th>Kontrol</th>
                            </tr>
                        </thead>
                        <?php $no = 1; ?>
                        <?php $__currentLoopData = $produks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $produk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tbody>
                                <tr>
                                    <td><?php echo e($no++); ?></td>
                                    <td><?php echo e($produk->kode_produk); ?></td>
                                    <td><?php echo e($produk->nama_produk); ?></td>
                                    <td><?php echo e("Rp. ".number_format($produk->harga, 0, ".", "." )); ?></td>
                                    <td><?php echo e($produk->stok); ?></td>
                                    <td>
                                        <form action="<?php echo e(route('produks.destroy', $produk->id)); ?>" method="post">
                                            <?php echo e(csrf_field()); ?>

                                            <?php echo e(method_field('DELETE')); ?>

                                            <a href="<?php echo e(route('produk.tambah', $produk->id)); ?>" class=" btn btn-sm btn-success">+Stok</a>
                                            <a href="<?php echo e(route('produks.edit',$produk->id)); ?>" class=" btn btn-sm btn-primary">Edit</a>
                                            <button class="btn btn-sm btn-danger" type="submit" onclick="return confirm('Yakin ingin menghapus data?')">Delete</button>
                                        </form>
                                    </td>
                                </tr>
                            </tbody>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </table>
                    <br>
                    <hr>
                    <?php echo $produks->appends(Request::except('page'))->links(); ?>

                   
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>